#' Reference data for SuessR Suess and Laws corrections
#'
#' @docType data
#'
#' @usage data(SuessR.reference.data)
#'
#' @format An object of class \code{"cross"}; see \code{\link[qtl]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Coming Soon
#'
#' @source Coming Soon
#'
#' @examples
#' data(SuessR.reference.data)
#'
"SuessR.reference.data"
