# SuessR 0.1.2

* Package now corrects data through 2020



# SuessR 0.1.1

* 'SuessR()' and 'SuessR.custom()' now return a warning when unrecognized
    columns present in input data.

* Output from 'SuessR()' and 'SuessR.custom()' now print to 3 decimal places, but
    are not rounded in the function output.

* Updated 'Cp' parameter values for all regions in the built-in
    'SuessR.reference.data' dataset.

* Corrected an error in the calculation of annual increase of surface ocean
    CO2 concentrations.